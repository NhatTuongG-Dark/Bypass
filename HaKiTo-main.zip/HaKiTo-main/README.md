# New Update HaKiTo 
```sh
Methods New
Update Proxy
Update Ua
```
# Welcome To HaKiTo
Không Được DDoS Website Chính Phủ<p align="center"><img src="https://i.imgur.com/kaQdEUB.jpg" width="300" height="250" alt="Script Tool"></p> 
# Setup and Run
```sh
git clone https://github.com/ViDucHung2006/HaKiTo
cd HaKiToV1.4.0
python setup.py
python3 main_new_v4.py
```

# Group Telegram
```sh
t.me/vdh_group
```
# Donate
* BTC: bc1qefl0awk7pjsylc8pct7lf8ypkxwet5rdg8p470
* Momo: 0359822840 <br>
CTK: Vi Đức Hùng 
* TP Bank: 42419052006 <br>
CTK: VI DUC HUNG 
# Developers
* Vi Duc Hung 

[![Hits](https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https://github.com/ViDucHung2006/HaKiToV1.4.0hit-counter&count_bg=%230BD4FF&title_bg=%23525050&icon=github.svg&icon_color=%23000000&title=Views&edge_flat=true)](https://hits.seeyoufarm.com)



